/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.bonus.treslinha.interfaces;

import pt.ips.pa.fase2.model.treslinha.interfaces.PecaTresLinha;

/**
 *
 * @author Morai
 */
public interface TemaPecaCharacterParser {

    public char parseChar(PecaTresLinha peca);

}
