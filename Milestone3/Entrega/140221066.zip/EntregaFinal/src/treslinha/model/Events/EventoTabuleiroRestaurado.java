
package treslinha.model.Events;

/**
 *
 * @author Ricardo José Horta Morais
 */
public class EventoTabuleiroRestaurado {
    

}
